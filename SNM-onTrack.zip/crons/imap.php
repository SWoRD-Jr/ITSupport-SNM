<?php

echo "This file has been deprecated and is just an alias for tickets.php.<br>Please use the tickets.php file instead. This file will be removed in a later version.<br><br>";

include("tickets.php");
?>
