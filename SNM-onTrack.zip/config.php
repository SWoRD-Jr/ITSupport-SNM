<?php

$config = array(
    "database_type" => "mysql",
    "database_name" => "snm_support",
    "server" => "localhost",
    "username" => "snm_support",
    "password" => "Iamsword2804",
    "charset" => "utf8",
    "port" => 3306,
    "encryption_key" => "ba11ef6ddffdca0dcd1f603d0479387f390297066f43950621591972dfb1831b");
?>